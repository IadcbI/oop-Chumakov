﻿using System;
using System.Text.Json.Serialization;

namespace TodoApp
{
    public class TodoItem
    {
        private string _title = "";
        private bool _done;
        private DateTime _dueDate;

        [JsonConstructor]
        public TodoItem(string title, DateTime dueDate, bool done)
        {
            Rename(title);
            _dueDate = dueDate;
            _done = done;
        }

        public TodoItem(string title, DateTime dueDate)
        {
            Rename(title);
            _dueDate = dueDate;
            _done = false;
        }

        public string Title 
        { 
            get => _title; 
            private set => Rename(value); 
        }
        
        public bool IsDone 
        { 
            get => _done; 
            private set => _done = value; 
        }

        public DateTime DueDate 
        { 
            get => _dueDate; 
            private set => _dueDate = value; 
        }

        public void Complete() => _done = true;

        public void Rename(string title)
        {
            if (string.IsNullOrWhiteSpace(title))
                throw new ArgumentException("Название не может быть пустым");
            _title = title.Trim();
        }
        
        public void ToggleDone() => _done = !_done;
    }
}