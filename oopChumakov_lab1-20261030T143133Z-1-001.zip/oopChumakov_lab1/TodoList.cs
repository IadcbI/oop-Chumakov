using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace TodoApp
{
    public enum TaskFilter { All, Active, Completed }
    public enum TaskSort { ByDate, ByTitle }

    public class TodoList
    {
        private List<TodoItem> _items = new List<TodoItem>();
        private readonly string _filePath = "tasks.json";

        public void Add(string title, DateTime dueDate)
        {
            var item = new TodoItem(title, dueDate);
            _items.Add(item);
            Save();
        }

        public void Remove(TodoItem item)
        {
            _items.Remove(item);
            Save();
        }

        public void Complete(TodoItem item)
        {
            item.Complete();
            Save();
        }

        public void Rename(TodoItem item, string newTitle)
        {
            item.Rename(newTitle);
            Save();
        }

        public List<TodoItem> GetItems(TaskFilter filter, TaskSort sort, string searchText)
        {
            var query = _items.AsEnumerable();

            if (filter == TaskFilter.Active)
                query = query.Where(i => !i.IsDone);
            else if (filter == TaskFilter.Completed)
                query = query.Where(i => i.IsDone);

            if (!string.IsNullOrWhiteSpace(searchText))
                query = query.Where(i => i.Title.Contains(searchText, StringComparison.OrdinalIgnoreCase));

            if (sort == TaskSort.ByDate)
                query = query.OrderBy(i => i.DueDate);
            else
                query = query.OrderBy(i => i.Title);

            return query.ToList();
        }

        public void Save()
        {
            try
            {
                string json = JsonSerializer.Serialize(_items, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(_filePath, json);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка сохранения: {ex.Message}");
            }
        }

        public void Load()
        {
            if (!File.Exists(_filePath)) return;
            try
            {
                string json = File.ReadAllText(_filePath);
                _items = JsonSerializer.Deserialize<List<TodoItem>>(json) ?? new List<TodoItem>();
            }
            catch
            {
                _items = new List<TodoItem>(); 
            }
        }

        public int TotalCount => _items.Count;
        public int CompletedCount => _items.Count(i => i.IsDone);
    }
}