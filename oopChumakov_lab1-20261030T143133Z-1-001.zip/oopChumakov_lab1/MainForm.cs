using System;
using System.Drawing;
using System.Windows.Forms;

namespace TodoApp
{
    public class MainForm : Form
    {
        private TodoList _todoList = new TodoList();
        
        private TextBox txtTitle;
        private DateTimePicker dtpDueDate;
        private Button btnAdd;
        
        private Button btnFilterAll, btnFilterActive, btnFilterCompleted;
        private ComboBox cmbSort;
        private TextBox txtSearch;
        
        private ListBox lstTasks;
        
        private Button btnComplete, btnRename, btnDelete;
        private Label lblStatus;

        private TaskFilter _currentFilter = TaskFilter.All;
        private TaskSort _currentSort = TaskSort.ByDate;

        public MainForm()
        {
            InitializeUI();
            _todoList.Load();
            RefreshList();
        }

        private void InitializeUI()
        {
            this.Text = "Мои задачи";
            this.Size = new Size(600, 500);
            this.StartPosition = FormStartPosition.CenterScreen;


            txtTitle = new TextBox { Location = new Point(20, 20), Width = 300, PlaceholderText = "Название задачи..." };
            dtpDueDate = new DateTimePicker { Location = new Point(330, 20), Width = 100, Format = DateTimePickerFormat.Short };
            btnAdd = new Button { Text = "Добавить", Location = new Point(440, 18), Width = 120, Height = 32 };
            btnAdd.Click += BtnAdd_Click;

           
            var lblFilter = new Label { Text = "Показать:", Location = new Point(20, 60), AutoSize = true };
            btnFilterAll = new Button { Text = "Все", Location = new Point(105, 55), Width = 60, Height = 32 };
            btnFilterActive = new Button { Text = "Активные", Location = new Point(170, 55), Width = 90, Height = 32 };
            btnFilterCompleted = new Button { Text = "Выполненные", Location = new Point(265, 55), Width = 120, Height = 32 };
            
            btnFilterAll.Click += (s, e) => SetFilter(TaskFilter.All);
            btnFilterActive.Click += (s, e) => SetFilter(TaskFilter.Active);
            btnFilterCompleted.Click += (s, e) => SetFilter(TaskFilter.Completed);

            txtSearch = new TextBox { Location = new Point(20, 90), Width = 200, PlaceholderText = "Поиск..." };
            txtSearch.TextChanged += (s, e) => RefreshList();

           
            cmbSort = new ComboBox { Location = new Point(400, 55), Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbSort.Items.Add("По сроку");
            cmbSort.Items.Add("По названию");
            cmbSort.SelectedIndex = 0;
            cmbSort.SelectedIndexChanged += (s, e) => { 
                _currentSort = cmbSort.SelectedIndex == 0 ? TaskSort.ByDate : TaskSort.ByTitle; 
                RefreshList(); 
            };

            
            lstTasks = new ListBox 
            { 
                Location = new Point(20, 120), 
                Size = new Size(540, 250), 
                DrawMode = DrawMode.OwnerDrawFixed, 
                ItemHeight = 30,
                BorderStyle = BorderStyle.FixedSingle
            };
            lstTasks.DrawItem += LstTasks_DrawItem;
            lstTasks.SelectedIndexChanged += (s, e) => UpdateButtons();

            
            btnComplete = new Button { Text = "✔ Выполнено", Location = new Point(20, 380), Width = 120, Height = 32 };
            btnRename = new Button { Text = "✎ Переименовать", Location = new Point(150, 380), Width = 120, Height = 32 };
            btnDelete = new Button { Text = "🗑 Удалить", Location = new Point(280, 380), Width = 100, Height = 32 };
            
            btnComplete.Click += BtnComplete_Click;
            btnRename.Click += BtnRename_Click;
            btnDelete.Click += BtnDelete_Click;

            
            lblStatus = new Label { Location = new Point(20, 420), AutoSize = true, ForeColor = Color.Gray };

            
            this.Controls.AddRange(new Control[] { 
                txtTitle, dtpDueDate, btnAdd, 
                lblFilter, btnFilterAll, btnFilterActive, btnFilterCompleted,
                txtSearch, cmbSort, lstTasks,
                btnComplete, btnRename, btnDelete, lblStatus 
            });
        }

        private void SetFilter(TaskFilter filter)
        {
            _currentFilter = filter;
            RefreshList();
        }

        private void RefreshList()
        {
            lstTasks.Items.Clear();
            var items = _todoList.GetItems(_currentFilter, _currentSort, txtSearch.Text);
            
            foreach (var item in items)
                lstTasks.Items.Add(item);

            lblStatus.Text = $"{_todoList.TotalCount} задач, выполнено {_todoList.CompletedCount} · сохранено в tasks.json";
            UpdateButtons();
        }

        private void UpdateButtons()
        {
            bool hasSelection = lstTasks.SelectedItem != null;
            btnComplete.Enabled = hasSelection;
            btnRename.Enabled = hasSelection;
            btnDelete.Enabled = hasSelection;
        }

        
        private void LstTasks_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            e.DrawBackground();
            
            var item = (TodoItem)lstTasks.Items[e.Index];
            
           
            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(220, 235, 252)), e.Bounds);
            else
                e.Graphics.FillRectangle(Brushes.White, e.Bounds);

            
            var checkRect = new Rectangle(e.Bounds.Left + 10, e.Bounds.Top + 7, 16, 16);
            e.Graphics.DrawRectangle(Pens.Gray, checkRect);
            if (item.IsDone)
            {
                e.Graphics.FillRectangle(Brushes.MediumSeaGreen, checkRect);
                e.Graphics.DrawString("✓", new Font("Arial", 10, FontStyle.Bold), Brushes.White, checkRect.X, checkRect.Y - 2);
            }

            
            Font font = item.IsDone ? new Font(e.Font, FontStyle.Strikeout) : e.Font;
            Color textColor = item.IsDone ? Color.Gray : Color.Black;
            e.Graphics.DrawString(item.Title, font, new SolidBrush(textColor), e.Bounds.Left + 35, e.Bounds.Top + 7);

            
            string dateStr = item.DueDate.ToString("dd.MM");
            Color dateColor = Color.Black;
            if (item.DueDate.Date < DateTime.Today && !item.IsDone)
                dateColor = Color.Red;
            else if (!item.IsDone)
                dateColor = Color.DimGray;

            var dateSize = e.Graphics.MeasureString(dateStr, e.Font);
            e.Graphics.DrawString(dateStr, e.Font, new SolidBrush(dateColor), e.Bounds.Right - dateSize.Width - 15, e.Bounds.Top + 7);

            e.DrawFocusRectangle();
        }

       
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                _todoList.Add(txtTitle.Text, dtpDueDate.Value);
                txtTitle.Clear();
                RefreshList();
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnComplete_Click(object sender, EventArgs e)
        {
            if (lstTasks.SelectedItem is TodoItem item)
            {
                _todoList.Complete(item);
                RefreshList();
            }
        }

                private void BtnRename_Click(object sender, EventArgs e)
        {
            if (lstTasks.SelectedItem is TodoItem item)
            {
               
                Form prompt = new Form()
                {
                    Width = 350,
                    Height = 150,
                    FormBorderStyle = FormBorderStyle.FixedDialog,
                    Text = "Переименовать задачу",
                    StartPosition = FormStartPosition.CenterScreen
                };
                Label textLabel = new Label() { Left = 20, Top = 20, Text = "Введите новое название:", AutoSize = true };
                TextBox textBox = new TextBox() { Left = 20, Top = 50, Width = 300, Text = item.Title };
                Button confirmation = new Button() { Text = "OK", Left = 220, Width = 100, Top = 80, DialogResult = DialogResult.OK };
                
                confirmation.Click += (sender, e) => { prompt.Close(); };
                
                prompt.Controls.Add(textBox);
                prompt.Controls.Add(confirmation);
                prompt.Controls.Add(textLabel);
                prompt.AcceptButton = confirmation;

                if (prompt.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        _todoList.Rename(item, textBox.Text);
                        RefreshList();
                    }
                    catch (ArgumentException ex)
                    {
                        MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (lstTasks.SelectedItem is TodoItem item)
            {
                var result = MessageBox.Show($"Удалить задачу \"{item.Title}\"?", "Подтверждение", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    _todoList.Remove(item);
                    RefreshList();
                }
            }
        }
    }
}